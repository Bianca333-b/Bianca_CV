﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG281_example
{
    public class Book : Item
    {
        public string Author { get; set; }

        public Book(string title, string genre, int year, string author)
            : base(title, genre, year)
        {
            Author = author;
        }

        public override void DisplayInfo()
        {
            Console.Clear();
            Console.WriteLine($"Book: {Title}");
            Console.WriteLine($"Genre: {Genre}");
            Console.WriteLine($"Year: {Year}");
            Console.WriteLine($"Author: {Author}");
            Console.WriteLine($"Completed: {IsCompleted}");
        }

        public void MarkAsRead()
        {
            IsCompleted = true;
        }
    }

}
