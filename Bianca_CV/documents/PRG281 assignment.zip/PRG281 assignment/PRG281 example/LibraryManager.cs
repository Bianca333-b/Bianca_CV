﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG281_example
{
    public class LibraryManager
    {
        public List<Item> collection;

        public LibraryManager()
        {
            collection = new List<Item>();
        }

        public void AddItem(Item item)
        {
            collection.Add(item);
            Console.WriteLine();
            Console.WriteLine($"{item.Title} added to the collection.");
        }

        public void MarkAsRead(Book book)
        {
            //book.MarkAsRead();
            book.IsCompleted = true;
            Console.WriteLine();
            Console.WriteLine($"{book.Title} marked as read.");
        }

        public void MarkAsWatched(Movie movie)
        {
            movie.MarkAsWatched();
            Console.WriteLine();
            Console.WriteLine($"{movie.Title} marked as watched.");
        }

        public void Search(string criteria)
        {
            var results = collection.Where(item => item.Title.Contains(criteria) || item.Genre.Contains(criteria)).ToList();
            foreach (var item in results)
            {
                item.DisplayInfo();
            }
        }

        public void DisplayUncompleted()
        {
            var uncompletedItems = collection.Where(item => !item.IsCompleted).ToList();
            foreach (var item in uncompletedItems)
            {
                item.DisplayInfo();
            }
        }
    }

}
