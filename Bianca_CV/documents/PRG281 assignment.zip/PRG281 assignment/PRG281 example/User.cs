﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG281_example
{
    public class User
    {
        public string Username { get; set; }
        private string Password { get; set; }

        public User(string username, string password)
        {
            Username = username;
            Password = password;
        }

        public bool Login(string username, string password)
        {
            return Username == username && Password == password;
        }

        public void ChangePassword(string newPassword)
        {
            Password = newPassword;
            Console.WriteLine("Password changed successfully.");
        }
    }

}
