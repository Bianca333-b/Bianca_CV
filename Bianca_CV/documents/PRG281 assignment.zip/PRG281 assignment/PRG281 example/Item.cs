﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG281_example
{
    public abstract class Item
    {
        public string Title { get; set; }
        public string Genre { get; set; }
        public int Year { get; set; }
        public bool IsCompleted { get; set; }

            public Item(string title, string genre, int year)
            {
                Title = title;
                Genre = genre;
                Year = year;
                IsCompleted = false;
            }

        public abstract void DisplayInfo();
    }

}



