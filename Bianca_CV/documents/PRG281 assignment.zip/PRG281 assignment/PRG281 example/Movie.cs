﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG281_example
{
    public class Movie : Item
    {
        public string Director { get; set; }

        public Movie(string title, string genre, int year, string director)
            : base(title, genre, year)
        {
            Director = director;
        }

        public override void DisplayInfo()
        {
            Console.Clear();
            Console.WriteLine($"Movie: {Title}");
            Console.WriteLine($"Genre: {Genre}");
            Console.WriteLine($"Year: {Year}");
            Console.WriteLine($"Director: {Director}");
            Console.WriteLine($" Completed: {IsCompleted}");
        }

        public void MarkAsWatched()
        {
            IsCompleted = true;
        }
    }

}
