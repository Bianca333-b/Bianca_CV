﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG281_example
{
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User("admin", "password");
            LibraryManager libraryManager = new LibraryManager();

            Console.WriteLine("Welcome to the Library Management System");
            Console.WriteLine("Please log in");

            /*  TO LOG IN USE THE USERNAME:"admin" AND THE PASSWORD:"password"  */

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("-----------------------------------------");
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write(" Username: ");
                Console.ForegroundColor = ConsoleColor.Green;
                string username = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write(" Password: ");
                Console.ForegroundColor = ConsoleColor.Green;
                string password = Console.ReadLine();
                Console.Clear();
                

                if (user.Login(username, password))
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("-----------------------------------------");
                    Console.WriteLine("|           Login successful!           |");
                    Console.WriteLine("|      Press any key to continue...     |");
                    Console.WriteLine("-----------------------------------------");
                    Console.ReadKey();
                    break;
                }
                else
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid credentials, please try again.");
                }
            }
            //main menu
            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("----------------------------------------------");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("|          Media Library Manager             |");
                Console.WriteLine("|                                            |");
                Console.WriteLine("|               Main Menu:                   |");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("----------------------------------------------");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("|            Select an option:               |");
                Console.WriteLine("|            ''''''''''''''''                |");
                Console.WriteLine("| 1. Add new book                            |");
                Console.WriteLine("| 2. Add new movie                           |");
                Console.WriteLine("| 3. Mark book as read                       |");
                Console.WriteLine("| 4. Mark movie as watched                   |");
                Console.WriteLine("| 5. Search collection                       |");
                Console.WriteLine("| 6. View unread/unwatched items             |");
                Console.WriteLine("| 7. Exit                                    |");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("----------------------------------------------");

                string choice = Console.ReadLine();
                //menu selector
                switch (choice)
                {
                    case "1":
                        AddNewBook(libraryManager);
                        break;
                    case "2":
                        AddNewMovie(libraryManager);
                        break;
                    case "3":
                        MarkBookAsRead(libraryManager);
                        break;
                    case "4":
                        MarkMovieAsWatched(libraryManager);
                        break;
                    case "5":
                        SearchCollection(libraryManager);
                        break;
                    case "6":
                        libraryManager.DisplayUncompleted();
                        break;
                    case "7":
                        return;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid option, please try again.");
                        break;
                }
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Press Enter to return to the main menu");
                Console.ReadLine();
            }
        }

        //Validate string input and return the value
        static string StringValadation()
        {
            string input = "";
            while (input.ToLower() == "")
            {
                input = Console.ReadLine();
                if (input == "")
                {
                    Console.WriteLine("Please enter a string.");
                }
                if (input.ToLower().Contains(" real."))
                {
                    Console.WriteLine("No it isn't");
                }
            }
            return input;
        }

        //add a book to the library
        static void AddNewBook(LibraryManager libraryManager)
        {
            Console.Clear();
            Console.Write("Enter title: ");
            string title = StringValadation();
            Console.WriteLine();        
            Console.Write("Enter genre: ");
            string genre = StringValadation();
            Console.WriteLine();
            Console.Write("Enter year: ");
            int year = 0;
            
            while (year < 1800)
            {                
                try
                {
                    year = int.Parse(Console.ReadLine());
                    if (year < 1800)
                    {
                        Console.Write("Be realistic...");
                    }
                }
                catch
                {
                    Console.WriteLine("Please enter a year.");
                }
            }
            Console.WriteLine();
            Console.Write("Enter author: ");
            string author = StringValadation();
            Console.Clear() ;

            Book book = new Book(title, genre, year, author);
            libraryManager.AddItem(book);
        }
        //add a movie to the library
        static void AddNewMovie(LibraryManager libraryManager)
        {
            Console.Clear();
            Console.Write("Enter title: ");
            string title = StringValadation();
            Console.WriteLine();
            Console.Write("Enter genre: ");
            string genre = StringValadation();
            Console.WriteLine();
            Console.Write("Enter year: ");
            int year = 0;
            while (year < 1800)
            {
                try
                {
                    year = int.Parse(Console.ReadLine());
                    if (year < 1800)
                    {
                        Console.Write("Be realistic...");
                    }
                }
                catch
                {
                    Console.WriteLine("Please enter a year.");
                }
            }
            Console.WriteLine();
            Console.Write("Enter director: ");
            string director = StringValadation();
            Console.Clear();

            Movie movie = new Movie(title, genre, year, director);
            libraryManager.AddItem(movie);
        }
        //Mark a book as read
        static void MarkBookAsRead(LibraryManager libraryManager)
        {
            Console.Clear();
            
            Console.Write("Enter title of the book to mark as read: ");
            string title = StringValadation();
        }
        //Mark a movie as watched
        static void MarkMovieAsWatched(LibraryManager libraryManager)
        {
            Console.Clear();
            
            Console.Write("Enter title of the movie to mark as watched: ");
            string title = StringValadation();
        }
        //Search trough the collection to find anything that matches the search criteria
        static void SearchCollection(LibraryManager libraryManager)
        {
            Console.Clear();
            
            Console.Write("Enter title, year, author, or genre into search criteria: ");
            string criteria = StringValadation();
            libraryManager.Search(criteria);
        }
    }
}